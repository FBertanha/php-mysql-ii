<?php
  include('header.php');?>

  <div class="row">
    <div class="col-md-4 col-md-offset-5">
      <h3>Bem Vindo</h3>
    </div>

  </div>
<?php
  include('footer.php');
?>
