function formatField(input) {
  console.log(input);
   //input.value = input.value + ".";
};
