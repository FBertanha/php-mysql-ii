<?php
  $conexao = mysqli_connect('localhost', 'root', 'bindas2', 'db_loja');
